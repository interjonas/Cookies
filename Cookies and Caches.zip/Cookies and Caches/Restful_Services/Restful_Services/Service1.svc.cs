﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace HW3
{
    public class Service1 : IService1
    {
        public string population(string input)
        {
            string population = "";
            input = input.ToLower();
            if (input.Equals("africa", StringComparison.OrdinalIgnoreCase))
            {
                population = "1,110,635,000";
            }
            else if (String.Equals(input, "asia", StringComparison.OrdinalIgnoreCase))
            {
                population = "4,298,723,000";
            }
            else if (input.Equals("europe", StringComparison.OrdinalIgnoreCase))
            {
                population = "742,452,000";
            }
            else if (input.Equals("north america", StringComparison.OrdinalIgnoreCase))
            {
                population = "565,265,000";
            }
            else if (input.Equals("south america", StringComparison.OrdinalIgnoreCase))
            {
                population = "406,740,000";
            }
            else if ((input.Equals("australia", StringComparison.OrdinalIgnoreCase)) || (input.Equals("oceania", StringComparison.OrdinalIgnoreCase)))
            {
                population = "38,304,000";
            }
            else if (input.Equals("antartica", StringComparison.OrdinalIgnoreCase))
            {
                population = "4,490";
            }
            else
            {
                population = "Invalid Input";
            }
            return population;
        }
        public string password(int passwordLength)
        {
            const string possibleCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*(){}[]|?.,";
            StringBuilder password = new StringBuilder();
            Random rnd = new Random();
            while (0 < passwordLength--)
            {
                password.Append(possibleCharacters[rnd.Next(possibleCharacters.Length)]);
            }
            return password.ToString();

        }
    }
}
