﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;

namespace webForm
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["myCookieID"];
            if((myCookies==null)||(myCookies["Continent"]==""))
            {
                Label1.Text = "New Continent Cookie";
                Label2.Text = "New Population Cookie";
            }
            else
            {
                Label1.Text = "Last time you entered " + myCookies["Continent"];
                Label2.Text = "Last time ouput was "+ myCookies["Population"];
            }
            String date = DateTime.Now.ToLongDateString();
            String time = DateTime.Now.ToLongTimeString();
            Label3.Text = "Cache: "+date + ", " + time;
        }
    }
}